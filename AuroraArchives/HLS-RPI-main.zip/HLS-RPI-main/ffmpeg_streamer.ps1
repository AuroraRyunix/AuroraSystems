


# Path to the FFmpeg and Nginx executables
$ffmpegPath = ".\ffmpeg.exe"
$nginxPath = ".\nginx.exe"
$stopNginxPath = ".\stopnginx.bat"

# File to store IP addresses
$ipFile = "ips.txt"

# Function to clear the display
function Clear-Display {
    Clear-Host
}

# Function to display the menu
function Show-Menu {
    Clear-Display
    Write-Host "FFmpeg Streaming Manager"
    Write-Host "1. Add IP Address"
    Write-Host "2. List IP Addresses"
    Write-Host "3. Clear IP Addresses"
    Write-Host "5. Start Streaming"
    Write-Host "6. Stop Streaming"
    Write-Host "7. List Running Streams"
    Write-Host "8. Start Nginx"
    Write-Host "9. Stop Nginx"
    Write-Host "0. Exit"
}

# Function to read IP addresses from file
function Get-IPs {
    if (Test-Path $ipFile) {
        Get-Content $ipFile
    } else {
        @()
    }
}

# Function to save IP addresses to file
function Save-IPs {
    $ips = Get-IPs
    $ips | Out-File -FilePath $ipFile -Force
}

# Function to validate IPv4 address
function Test-ValidIP {
    param (
        [string]$ip
    )

    # Split the IP address into octets
    $octets = $ip -split '\.'
    
    # Check if there are exactly 4 octets
    if ($octets.Length -ne 4) {
        return $false
    }
    
    # Validate each octet
    foreach ($octet in $octets) {
        if (-not ($octet -match '^\d{1,3}$')) {
            return $false
        }
        $number = [int]$octet
        if ($number -lt 0 -or $number -gt 255) {
            return $false
        }
    }
    
    return $true
}

# Function to add an IP address
function Add-IP {
    $ip = Read-Host "Enter IP Address"
    if (-not (Test-ValidIP $ip)) {
        Write-Host "Invalid IP Address."
        Write-Host "Press any key to return to menu..."
        [void][System.Console]::ReadKey($true)
        return
    }
    $ips = Get-IPs
    if ($ips -contains $ip) {
        Write-Host "IP Address already exists."
    } else {
        $ip | Out-File -Append -FilePath $ipFile
        Write-Host "IP Address added."
    }
    Write-Host "Press any key to return to menu..."
    [void][System.Console]::ReadKey($true)
}

# Function to list IP addresses
function List-IPs {
    Clear-Display
    Write-Host "Current IP Addresses:"
    Get-IPs
    Write-Host "Press any key to return to menu..."
    [void][System.Console]::ReadKey($true)
}

# Function to clear IP addresses
function Clear-IPs {
    if (Test-Path $ipFile) {
        Remove-Item $ipFile -ErrorAction SilentlyContinue
        Write-Host "IP Addresses cleared."
    } else {
        Write-Host "No IP Addresses to clear."
    }
    Write-Host "Press any key to return to menu..."
    [void][System.Console]::ReadKey($true)
}

# Function to start streaming
function Start-Streaming {
    $ips = Get-IPs
    if ($ips.Count -eq 0) {
        Write-Host "No IP addresses to stream to."
        Write-Host "Press any key to return to menu..."
        [void][System.Console]::ReadKey($true)
        return
    }

    foreach ($ip in $ips) {
        $ffmpegArgs = "-i rtmp://localhost:1935/live -c:v libx264 -b:v 4M -preset veryfast -tune zerolatency -bufsize 1M -fflags nobuffer -f mpegts udp://$($ip):8000?pkt_size=1316"
        Start-Process -FilePath $ffmpegPath -ArgumentList $ffmpegArgs -WindowStyle Normal
    }
    Write-Host "Streaming started."
    Write-Host "Press any key to return to menu..."
    [void][System.Console]::ReadKey($true)
}

# Function to stop streaming
function Stop-Streaming {
    Stop-Process -Name "ffmpeg" -ErrorAction SilentlyContinue
    Write-Host "Streaming stopped."
    Write-Host "Press any key to return to menu..."
    [void][System.Console]::ReadKey($true)
}

# Function to list running streams
function List-Streams {
    Clear-Display
    $processes = Get-Process -Name "ffmpeg" -ErrorAction SilentlyContinue
    if ($processes) {
        Write-Host "Currently running FFmpeg streams:"
        $processes | ForEach-Object { Write-Host "Process ID: $($_.Id), Name: $($_.Name)" }
    } else {
        Write-Host "No FFmpeg processes are currently running."
    }
    Write-Host "Press any key to return to menu..."
    [void][System.Console]::ReadKey($true)
}

# Function to start Nginx
function Start-Nginx {
    Start-Process -FilePath $nginxPath -WindowStyle Normal
    Write-Host "Nginx started."
    Write-Host "Press any key to return to menu..."
    [void][System.Console]::ReadKey($true)
}

# Function to stop Nginx
function Stop-Nginx {
    Start-Process -FilePath $stopNginxPath -WindowStyle Normal
    Write-Host "Stopping Nginx..."
    Write-Host "Press any key to return to menu..."
    [void][System.Console]::ReadKey($true)
}

# Load IPs from file on startup
if (-not (Test-Path $ipFile)) {
    New-Item -ItemType File -Path $ipFile -Force | Out-Null
}

# Main script loop
while ($true) {
    Show-Menu
    $choice = Read-Host "Select an option"

    switch ($choice) {
        1 { Add-IP }
        2 { List-IPs }
        3 { Clear-IPs }
        5 { Start-Streaming }
        6 { Stop-Streaming }
        7 { List-Streams }
        8 { Start-Nginx }
        9 { Stop-Nginx }
        0 { break }
        default {
            Write-Host "Invalid choice, please try again."
            Start-Sleep -Seconds 2
        }
    }
}
