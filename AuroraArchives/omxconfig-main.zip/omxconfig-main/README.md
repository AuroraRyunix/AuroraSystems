# omxconfig
OMXplayer Real time RTSP retail screenplay, using only open source components

friendly reminder to launch MediaMTX with the path aura

second friendly reminder: you need not know the password, as you need not change shit. use the non root public key authentication instead!
(i don't like people messing around with my shit, you know)
