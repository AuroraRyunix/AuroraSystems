rhel 9.4
OBS-studio from snapd
mediaMTX stable 1.90
