# RPI-AR-PB
AuroraSystems openMAX vlc video player with SRT support
